"""
AI Damage Detection Module
PyTorch 기반 한옥 손상 탐지 모듈
"""
