"""
Heritage API Module
국가유산청 API 프록시 기능
"""
