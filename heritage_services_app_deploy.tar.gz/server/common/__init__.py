"""
Common Module
공통 설정 및 미들웨어
"""
